<?php

/* todo/details.html.twig */
class __TwigTemplate_6500970abe022a2c6c48f5ef160bf6b7707d05b29deb571fe7ff8c200d2fefab extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "todo/details.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7ec6809dd8fafafaa353ef4c9e3573f7836fc6b8b3507efe3b0d6c0f5f070283 = $this->env->getExtension("native_profiler");
        $__internal_7ec6809dd8fafafaa353ef4c9e3573f7836fc6b8b3507efe3b0d6c0f5f070283->enter($__internal_7ec6809dd8fafafaa353ef4c9e3573f7836fc6b8b3507efe3b0d6c0f5f070283_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "todo/details.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7ec6809dd8fafafaa353ef4c9e3573f7836fc6b8b3507efe3b0d6c0f5f070283->leave($__internal_7ec6809dd8fafafaa353ef4c9e3573f7836fc6b8b3507efe3b0d6c0f5f070283_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_5ac7b1c82c1cc0566bdca977f35c9e434cf605ddd7a1bdf35efc1d3d953be217 = $this->env->getExtension("native_profiler");
        $__internal_5ac7b1c82c1cc0566bdca977f35c9e434cf605ddd7a1bdf35efc1d3d953be217->enter($__internal_5ac7b1c82c1cc0566bdca977f35c9e434cf605ddd7a1bdf35efc1d3d953be217_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <a class=\"btn btn-default\" href=\"/\">Back to Todos</a>
    <hr>
    <h2 class=\"page-header\">";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["todo"]) ? $context["todo"] : $this->getContext($context, "todo")), "name", array()), "html", null, true);
        echo "</h2>
    <ul class=\"list-group\">
        <li class=\"list-group-item\">Category: ";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["todo"]) ? $context["todo"] : $this->getContext($context, "todo")), "category", array()), "html", null, true);
        echo "</li>
        <li class=\"list-group-item\">Priority: ";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["todo"]) ? $context["todo"] : $this->getContext($context, "todo")), "priority", array()), "html", null, true);
        echo "
        <li class=\"list-group-item\">Due: <strong>";
        // line 10
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["todo"]) ? $context["todo"] : $this->getContext($context, "todo")), "dueDate", array()), "F j, Y, g:i a"), "html", null, true);
        echo "</strong></li>
    </ul>
    <p>
        ";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["todo"]) ? $context["todo"] : $this->getContext($context, "todo")), "description", array()), "html", null, true);
        echo "
    </p>
";
        
        $__internal_5ac7b1c82c1cc0566bdca977f35c9e434cf605ddd7a1bdf35efc1d3d953be217->leave($__internal_5ac7b1c82c1cc0566bdca977f35c9e434cf605ddd7a1bdf35efc1d3d953be217_prof);

    }

    public function getTemplateName()
    {
        return "todo/details.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  63 => 13,  57 => 10,  53 => 9,  49 => 8,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/*     <a class="btn btn-default" href="/">Back to Todos</a>*/
/*     <hr>*/
/*     <h2 class="page-header">{{ todo.name }}</h2>*/
/*     <ul class="list-group">*/
/*         <li class="list-group-item">Category: {{ todo.category }}</li>*/
/*         <li class="list-group-item">Priority: {{ todo.priority }}*/
/*         <li class="list-group-item">Due: <strong>{{ todo.dueDate|date('F j, Y, g:i a') }}</strong></li>*/
/*     </ul>*/
/*     <p>*/
/*         {{ todo.description }}*/
/*     </p>*/
/* {% endblock %}*/

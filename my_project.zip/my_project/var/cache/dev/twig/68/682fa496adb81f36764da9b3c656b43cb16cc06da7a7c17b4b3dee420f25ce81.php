<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_c2b3abc686828bb78cbb8c3efc483e35e08657a783485d90ea3d6600f73a87df extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3ef36c8640aa95d6608d3359e6a499971ef2b91094f51ef702aa9335ccc806c1 = $this->env->getExtension("native_profiler");
        $__internal_3ef36c8640aa95d6608d3359e6a499971ef2b91094f51ef702aa9335ccc806c1->enter($__internal_3ef36c8640aa95d6608d3359e6a499971ef2b91094f51ef702aa9335ccc806c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3ef36c8640aa95d6608d3359e6a499971ef2b91094f51ef702aa9335ccc806c1->leave($__internal_3ef36c8640aa95d6608d3359e6a499971ef2b91094f51ef702aa9335ccc806c1_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_25da74df28a91b23846a7c85dafa85108fa3b8d41aff749e04ccd36cfcab9055 = $this->env->getExtension("native_profiler");
        $__internal_25da74df28a91b23846a7c85dafa85108fa3b8d41aff749e04ccd36cfcab9055->enter($__internal_25da74df28a91b23846a7c85dafa85108fa3b8d41aff749e04ccd36cfcab9055_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_25da74df28a91b23846a7c85dafa85108fa3b8d41aff749e04ccd36cfcab9055->leave($__internal_25da74df28a91b23846a7c85dafa85108fa3b8d41aff749e04ccd36cfcab9055_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_db55db40ba2f94953d0c714a80098c300fc20c417ae63b9b8c098d186dbe55b0 = $this->env->getExtension("native_profiler");
        $__internal_db55db40ba2f94953d0c714a80098c300fc20c417ae63b9b8c098d186dbe55b0->enter($__internal_db55db40ba2f94953d0c714a80098c300fc20c417ae63b9b8c098d186dbe55b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_db55db40ba2f94953d0c714a80098c300fc20c417ae63b9b8c098d186dbe55b0->leave($__internal_db55db40ba2f94953d0c714a80098c300fc20c417ae63b9b8c098d186dbe55b0_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_defd78c220356dd4ee60f75de0c4fc72c7d8b99ed0c43248dcc5b828a7fc227f = $this->env->getExtension("native_profiler");
        $__internal_defd78c220356dd4ee60f75de0c4fc72c7d8b99ed0c43248dcc5b828a7fc227f->enter($__internal_defd78c220356dd4ee60f75de0c4fc72c7d8b99ed0c43248dcc5b828a7fc227f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('routing')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_defd78c220356dd4ee60f75de0c4fc72c7d8b99ed0c43248dcc5b828a7fc227f->leave($__internal_defd78c220356dd4ee60f75de0c4fc72c7d8b99ed0c43248dcc5b828a7fc227f_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@WebProfiler/Profiler/layout.html.twig' %}*/
/* */
/* {% block toolbar %}{% endblock %}*/
/* */
/* {% block menu %}*/
/* <span class="label">*/
/*     <span class="icon">{{ include('@WebProfiler/Icon/router.svg') }}</span>*/
/*     <strong>Routing</strong>*/
/* </span>*/
/* {% endblock %}*/
/* */
/* {% block panel %}*/
/*     {{ render(path('_profiler_router', { token: token })) }}*/
/* {% endblock %}*/
/* */

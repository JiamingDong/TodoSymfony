<?php

/* base.html.twig */
class __TwigTemplate_a319a0033fac202537e806d44fc977fa28fa4a42cbe1998492b560e730253c00 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e586d8e3f7b066e156b4ec905c489b6e2d57e685a06bad09e1457624829b9f93 = $this->env->getExtension("native_profiler");
        $__internal_e586d8e3f7b066e156b4ec905c489b6e2d57e685a06bad09e1457624829b9f93->enter($__internal_e586d8e3f7b066e156b4ec905c489b6e2d57e685a06bad09e1457624829b9f93_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">
    <link rel=\"icon\" href=\"../../favicon.ico\">

    <title>";
        // line 12
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    <!-- Bootstrap core CSS -->
    <link href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css\" rel=\"stylesheet\">
    ";
        // line 16
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 17
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
</head>

<body>

<nav class=\"navbar navbar-inverse\">
    <div class=\"container\">
        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar\" aria-expanded=\"false\" aria-controls=\"navbar\">
                <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand\" href=\"/\">Todolist</a>
        </div>
        <div id=\"navbar\" class=\"collapse navbar-collapse\">
            <ul class=\"nav navbar-nav\">
                <li class=\"active\"><a href=\"/\">Home</a></li>
                <li><a href=\"/todo/create\">Add Todo</a></li>
            </ul>
        </div><!--/.nav-collapse -->
    </div>
</nav>

<div class=\"container\">
    <div class=\"row\">
        <div class=\"col-md-12\">
            ";
        // line 45
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "notice"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flash_message"]) {
            // line 46
            echo "                <div class=\"alert alert-success\">";
            echo twig_escape_filter($this->env, $context["flash_message"], "html", null, true);
            echo "</div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flash_message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 48
        echo "
            ";
        // line 49
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "error"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flash_message"]) {
            // line 50
            echo "                <div class=\"alert alert-danger\">";
            echo twig_escape_filter($this->env, $context["flash_message"], "html", null, true);
            echo "</div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flash_message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 52
        echo "
            ";
        // line 53
        $this->displayBlock('body', $context, $blocks);
        // line 54
        echo "        </div>
    </div>
</div><!-- /.container -->

";
        // line 58
        $this->displayBlock('javascripts', $context, $blocks);
        // line 59
        echo "
</body>
</html>

";
        
        $__internal_e586d8e3f7b066e156b4ec905c489b6e2d57e685a06bad09e1457624829b9f93->leave($__internal_e586d8e3f7b066e156b4ec905c489b6e2d57e685a06bad09e1457624829b9f93_prof);

    }

    // line 12
    public function block_title($context, array $blocks = array())
    {
        $__internal_a62cd85cb708514c9b7e68234390193e820d80c679314283336e22347e3ddb15 = $this->env->getExtension("native_profiler");
        $__internal_a62cd85cb708514c9b7e68234390193e820d80c679314283336e22347e3ddb15->enter($__internal_a62cd85cb708514c9b7e68234390193e820d80c679314283336e22347e3ddb15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_a62cd85cb708514c9b7e68234390193e820d80c679314283336e22347e3ddb15->leave($__internal_a62cd85cb708514c9b7e68234390193e820d80c679314283336e22347e3ddb15_prof);

    }

    // line 16
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_4f75e1162261ff347466b1d6a5843bbe4fba204232914cd713c60a692849f540 = $this->env->getExtension("native_profiler");
        $__internal_4f75e1162261ff347466b1d6a5843bbe4fba204232914cd713c60a692849f540->enter($__internal_4f75e1162261ff347466b1d6a5843bbe4fba204232914cd713c60a692849f540_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_4f75e1162261ff347466b1d6a5843bbe4fba204232914cd713c60a692849f540->leave($__internal_4f75e1162261ff347466b1d6a5843bbe4fba204232914cd713c60a692849f540_prof);

    }

    // line 53
    public function block_body($context, array $blocks = array())
    {
        $__internal_3288a5b60a3ff32070c67e1715786b127cfbe490cc7abbd28e3876eda2a5865a = $this->env->getExtension("native_profiler");
        $__internal_3288a5b60a3ff32070c67e1715786b127cfbe490cc7abbd28e3876eda2a5865a->enter($__internal_3288a5b60a3ff32070c67e1715786b127cfbe490cc7abbd28e3876eda2a5865a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_3288a5b60a3ff32070c67e1715786b127cfbe490cc7abbd28e3876eda2a5865a->leave($__internal_3288a5b60a3ff32070c67e1715786b127cfbe490cc7abbd28e3876eda2a5865a_prof);

    }

    // line 58
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_de7ee5a41fcc6e65c8fa1ffc2b99655677a3bdc72f962dfb9390e136685033f7 = $this->env->getExtension("native_profiler");
        $__internal_de7ee5a41fcc6e65c8fa1ffc2b99655677a3bdc72f962dfb9390e136685033f7->enter($__internal_de7ee5a41fcc6e65c8fa1ffc2b99655677a3bdc72f962dfb9390e136685033f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_de7ee5a41fcc6e65c8fa1ffc2b99655677a3bdc72f962dfb9390e136685033f7->leave($__internal_de7ee5a41fcc6e65c8fa1ffc2b99655677a3bdc72f962dfb9390e136685033f7_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  167 => 58,  156 => 53,  145 => 16,  133 => 12,  122 => 59,  120 => 58,  114 => 54,  112 => 53,  109 => 52,  100 => 50,  96 => 49,  93 => 48,  84 => 46,  80 => 45,  48 => 17,  46 => 16,  39 => 12,  26 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html lang="en">*/
/* <head>*/
/*     <meta charset="utf-8">*/
/*     <meta http-equiv="X-UA-Compatible" content="IE=edge">*/
/*     <meta name="viewport" content="width=device-width, initial-scale=1">*/
/*     <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->*/
/*     <meta name="description" content="">*/
/*     <meta name="author" content="">*/
/*     <link rel="icon" href="../../favicon.ico">*/
/* */
/*     <title>{% block title %}Welcome!{% endblock %}</title>*/
/* */
/*     <!-- Bootstrap core CSS -->*/
/*     <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">*/
/*     {% block stylesheets %}{% endblock %}*/
/*     <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/* </head>*/
/* */
/* <body>*/
/* */
/* <nav class="navbar navbar-inverse">*/
/*     <div class="container">*/
/*         <div class="navbar-header">*/
/*             <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">*/
/*                 <span class="sr-only">Toggle navigation</span>*/
/*                 <span class="icon-bar"></span>*/
/*                 <span class="icon-bar"></span>*/
/*                 <span class="icon-bar"></span>*/
/*             </button>*/
/*             <a class="navbar-brand" href="/">Todolist</a>*/
/*         </div>*/
/*         <div id="navbar" class="collapse navbar-collapse">*/
/*             <ul class="nav navbar-nav">*/
/*                 <li class="active"><a href="/">Home</a></li>*/
/*                 <li><a href="/todo/create">Add Todo</a></li>*/
/*             </ul>*/
/*         </div><!--/.nav-collapse -->*/
/*     </div>*/
/* </nav>*/
/* */
/* <div class="container">*/
/*     <div class="row">*/
/*         <div class="col-md-12">*/
/*             {% for flash_message in app.session.flashbag.get('notice') %}*/
/*                 <div class="alert alert-success">{{ flash_message }}</div>*/
/*             {% endfor %}*/
/* */
/*             {% for flash_message in app.session.flashbag.get('error') %}*/
/*                 <div class="alert alert-danger">{{ flash_message }}</div>*/
/*             {% endfor %}*/
/* */
/*             {% block body %}{% endblock %}*/
/*         </div>*/
/*     </div>*/
/* </div><!-- /.container -->*/
/* */
/* {% block javascripts %}{% endblock %}*/
/* */
/* </body>*/
/* </html>*/
/* */
/* */

<?php

/* todo/create.html.twig */
class __TwigTemplate_495b1dfee40266d52886f21df10b61e6323f5ecdfcdabfa6771abc3f6f035227 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "todo/create.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4148ad423d27388890314f681e7bb15ffa561c2c83b57cf738de95df5bf03f81 = $this->env->getExtension("native_profiler");
        $__internal_4148ad423d27388890314f681e7bb15ffa561c2c83b57cf738de95df5bf03f81->enter($__internal_4148ad423d27388890314f681e7bb15ffa561c2c83b57cf738de95df5bf03f81_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "todo/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4148ad423d27388890314f681e7bb15ffa561c2c83b57cf738de95df5bf03f81->leave($__internal_4148ad423d27388890314f681e7bb15ffa561c2c83b57cf738de95df5bf03f81_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_80fcb6280d54620c4972603033e9e655f0fedc1d21d51b1e5009bad02bc6b7a4 = $this->env->getExtension("native_profiler");
        $__internal_80fcb6280d54620c4972603033e9e655f0fedc1d21d51b1e5009bad02bc6b7a4->enter($__internal_80fcb6280d54620c4972603033e9e655f0fedc1d21d51b1e5009bad02bc6b7a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h2 class=\"page-header\">Add Todo</h2>
    ";
        // line 5
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
    ";
        // line 6
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
    ";
        // line 7
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
";
        
        $__internal_80fcb6280d54620c4972603033e9e655f0fedc1d21d51b1e5009bad02bc6b7a4->leave($__internal_80fcb6280d54620c4972603033e9e655f0fedc1d21d51b1e5009bad02bc6b7a4_prof);

    }

    public function getTemplateName()
    {
        return "todo/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  51 => 7,  47 => 6,  43 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/*     <h2 class="page-header">Add Todo</h2>*/
/*     {{ form_start(form) }}*/
/*     {{ form_widget(form) }}*/
/*     {{ form_end(form) }}*/
/* {% endblock %}*/

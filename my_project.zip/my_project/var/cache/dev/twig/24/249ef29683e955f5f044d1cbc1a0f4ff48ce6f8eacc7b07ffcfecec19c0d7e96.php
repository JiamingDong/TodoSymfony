<?php

/* todo/edit.html.twig */
class __TwigTemplate_3cd41fd3a088e22087fe9de65386ffb91da69ffd1edacd7a1cf0a121f173cf22 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "todo/edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f5fbef740178b0502d8df54eea2f775bf25cf979fc302e2a8238951ed14ef45f = $this->env->getExtension("native_profiler");
        $__internal_f5fbef740178b0502d8df54eea2f775bf25cf979fc302e2a8238951ed14ef45f->enter($__internal_f5fbef740178b0502d8df54eea2f775bf25cf979fc302e2a8238951ed14ef45f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "todo/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f5fbef740178b0502d8df54eea2f775bf25cf979fc302e2a8238951ed14ef45f->leave($__internal_f5fbef740178b0502d8df54eea2f775bf25cf979fc302e2a8238951ed14ef45f_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_23cd268b3002d3c8f2c1a788da7e2eb0f66255e4fddf9cfe9977290c3a665ad8 = $this->env->getExtension("native_profiler");
        $__internal_23cd268b3002d3c8f2c1a788da7e2eb0f66255e4fddf9cfe9977290c3a665ad8->enter($__internal_23cd268b3002d3c8f2c1a788da7e2eb0f66255e4fddf9cfe9977290c3a665ad8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h2 class=\"page-header\">Edit Todo</h2>
    ";
        // line 5
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
    ";
        // line 6
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
    ";
        // line 7
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
";
        
        $__internal_23cd268b3002d3c8f2c1a788da7e2eb0f66255e4fddf9cfe9977290c3a665ad8->leave($__internal_23cd268b3002d3c8f2c1a788da7e2eb0f66255e4fddf9cfe9977290c3a665ad8_prof);

    }

    public function getTemplateName()
    {
        return "todo/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  51 => 7,  47 => 6,  43 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/*     <h2 class="page-header">Edit Todo</h2>*/
/*     {{ form_start(form) }}*/
/*     {{ form_widget(form) }}*/
/*     {{ form_end(form) }}*/
/* {% endblock %}*/
